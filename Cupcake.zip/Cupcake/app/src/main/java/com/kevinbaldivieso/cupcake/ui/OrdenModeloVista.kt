package com.kevinbaldivieso.cupcake.ui

import androidx.lifecycle.ViewModel
import com.kevinbaldivieso.cupcake.data.OrdenarEstadoUI
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private const val PRECIO_POR_CUPCAKE = 2.00

private const val PRECIO_PARA_RECOGER_MISMO_DIA = 3.00

class OrdenModeloVista : ViewModel() {

    private val _estadoUI = MutableStateFlow(OrdenarEstadoUI(opcionesElegidas = opcionesRecogida()))
    val estadoUI: StateFlow<OrdenarEstadoUI> = _estadoUI.asStateFlow()

    fun establecerCantidad(numeroCupcakes: Int) {
        _estadoUI.update { currentState ->
            currentState.copy(
                cantidad = numeroCupcakes,
                precio = calcularPrecio(cantidad = numeroCupcakes)
            )
        }
    }

    fun establecerSabor(saborDeseado: String) {
        _estadoUI.update { currentState ->
            currentState.copy(sabor = saborDeseado)
        }
    }

    fun establecerFecha(fechaRecogida: String) {
        _estadoUI.update { currentState ->
            currentState.copy(
                fecha = fechaRecogida,
                precio = calcularPrecio(fechaRecogida = fechaRecogida)
            )
        }
    }

    fun resetearOrden() {
        _estadoUI.value = OrdenarEstadoUI(opcionesElegidas = opcionesRecogida())
    }

    private fun calcularPrecio(
        cantidad: Int = _estadoUI.value.cantidad,
        fechaRecogida: String = _estadoUI.value.fecha
    ): String {
        var precioCalculado = cantidad * PRECIO_POR_CUPCAKE
        if (opcionesRecogida()[0] == fechaRecogida) {
            precioCalculado += PRECIO_PARA_RECOGER_MISMO_DIA
        }
        return NumberFormat.getCurrencyInstance().format(precioCalculado)
    }

    private fun opcionesRecogida(): List<String> {
        val fechaOpciones = mutableListOf<String>()
        val formateador = SimpleDateFormat("E MMM d", Locale.getDefault())
        val calendario = Calendar.getInstance()
        // add current date and the following 3 dates.
        repeat(4) {
            fechaOpciones.add(formateador.format(calendario.time))
            calendario.add(Calendar.DATE, 1)
        }
        return fechaOpciones
    }
}
