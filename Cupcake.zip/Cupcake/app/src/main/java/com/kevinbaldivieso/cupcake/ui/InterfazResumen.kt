package com.kevinbaldivieso.cupcake.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import com.kevinbaldivieso.cupcake.R
import com.kevinbaldivieso.cupcake.data.OrdenarEstadoUI
import com.kevinbaldivieso.cupcake.ui.componentes.EtiquetaPrecioFormateada
import com.kevinbaldivieso.cupcake.ui.theme.CupcakeTheme

@Composable
fun InterfazResumenPedido(
    ordenarEstadoUI: OrdenarEstadoUI,
    clicBotonCancelar: () -> Unit,
    clicBotonEnviar: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val recursos = LocalContext.current.resources

    val numeroDeCupcakes = recursos.getQuantityString(
        R.plurals.cupcakes,
        ordenarEstadoUI.cantidad,
        ordenarEstadoUI.cantidad
    )

    val pedidoResumen = stringResource(
        R.string.detalles_pedido,
        numeroDeCupcakes,
        ordenarEstadoUI.sabor,
        ordenarEstadoUI.fecha,
        ordenarEstadoUI.cantidad
    )
    val nuevoPedido = stringResource(R.string.nuevo_pedido_cupcake)

    val elementos = listOf(

        Pair(stringResource(R.string.cantidad), numeroDeCupcakes),

        Pair(stringResource(R.string.sabor), ordenarEstadoUI.sabor),

        Pair(stringResource(R.string.fecha_recogida), ordenarEstadoUI.fecha)
    )

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.padding(dimensionResource(R.dimen.padding_medium)),
            verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_small))
        ) {
            elementos.forEach { item ->
                Text(item.first.uppercase())
                Text(text = item.second, fontWeight = FontWeight.Bold)
                HorizontalDivider(thickness = dimensionResource(R.dimen.thickness_divider))
            }
            Spacer(modifier = Modifier.height(dimensionResource(R.dimen.padding_small)))
            EtiquetaPrecioFormateada(
                subtotal = ordenarEstadoUI.precio,
                modifier = Modifier.align(Alignment.End)
            )
        }
        Row(
            modifier = Modifier.padding(dimensionResource(R.dimen.padding_medium))
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_small))
            ) {
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { clicBotonEnviar(nuevoPedido, pedidoResumen) }
                ) {
                    Text(stringResource(R.string.enviar))
                }
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = clicBotonCancelar
                ) {
                    Text(stringResource(R.string.cancelar))
                }
            }
        }
    }
}

@Preview
@Composable
fun PedidoResumenPreview() {
    CupcakeTheme {
        InterfazResumenPedido(
            ordenarEstadoUI = OrdenarEstadoUI(0, "Test", "Test", "$300.00"),
            clicBotonEnviar = { subject: String, summary: String -> },
            clicBotonCancelar = {},
            modifier = Modifier.fillMaxHeight()
        )
    }
}
