package com.kevinbaldivieso.cupcake.data

data class OrdenarEstadoUI(
    val cantidad: Int = 0,
    val sabor: String = "",
    val fecha: String = "",
    val precio: String = "",
    val opcionesElegidas: List<String> = listOf()
)
