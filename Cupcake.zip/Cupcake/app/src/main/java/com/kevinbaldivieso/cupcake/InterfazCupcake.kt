package com.kevinbaldivieso.cupcake

import android.content.Context
import android.content.Intent
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kevinbaldivieso.cupcake.data.RecursoDatos
import com.kevinbaldivieso.cupcake.ui.InterfazInicioPedido
import com.kevinbaldivieso.cupcake.ui.InterfazOpcionSeleccionada
import com.kevinbaldivieso.cupcake.ui.InterfazResumenPedido
import com.kevinbaldivieso.cupcake.ui.OrdenModeloVista

enum class InterfazCupcakes(@StringRes val titulo: Int) {
    Iniciar(titulo = R.string.app_name),
    Sabor(titulo = R.string.elegir_sabor),
    Escoger(titulo = R.string.elegir_fecha_recogida),
    Resumen(titulo = R.string.resumen_pedido)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CupcakeBarraSuperior(
    interfazActual: InterfazCupcakes,
    navegarDevuelta: Boolean,
    navegarArriba: () -> Unit,
    modifier: Modifier = Modifier
) {
    TopAppBar(
        title = { Text(stringResource(interfazActual.titulo)) },
        colors = TopAppBarDefaults.mediumTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        modifier = modifier,
        navigationIcon = {
            if (navegarDevuelta) {
                IconButton(onClick = navegarArriba) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.boton_atras)
                    )
                }
            }
        }
    )
}

@Composable
fun CupcakeApp(
    modeloVista: OrdenModeloVista = viewModel(),
    controlNav: NavHostController = rememberNavController()
) {
    val entradaPilaTrasera by controlNav.currentBackStackEntryAsState()
    val pantallaActual = InterfazCupcakes.valueOf(
        entradaPilaTrasera?.destination?.route ?: InterfazCupcakes.Iniciar.name
    )

    Scaffold(
        topBar = {
            CupcakeBarraSuperior(
                interfazActual = pantallaActual,
                navegarDevuelta = controlNav.previousBackStackEntry != null,
                navegarArriba = { controlNav.navigateUp() }
            )
        }
    ) { innerPadding ->
        val estadoUI by modeloVista.estadoUI.collectAsState()

        NavHost(
            navController = controlNav,
            startDestination = InterfazCupcakes.Iniciar.name,
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
        ) {
            composable(route = InterfazCupcakes.Iniciar.name) {
                InterfazInicioPedido(
                    opcionesCantidad = RecursoDatos.cantidadOpciones,
                    clicBotonSiguiente = {
                        modeloVista.establecerCantidad(it)
                        controlNav.navigate(InterfazCupcakes.Sabor.name)
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(dimensionResource(R.dimen.padding_medium))
                )
            }
            composable(route = InterfazCupcakes.Sabor.name) {
                val contexto = LocalContext.current
                InterfazOpcionSeleccionada(
                    subtotal = estadoUI.precio,
                    clicBotonSiguiente = { controlNav.navigate(InterfazCupcakes.Escoger.name) },
                    clicBotonCancelar = {
                        cancelarPedidoYNavegarInicio(modeloVista, controlNav)
                    },
                    opciones = RecursoDatos.sabores.map { id -> contexto.resources.getString(id) },
                    seleccionCambiada = { modeloVista.establecerSabor(it) },
                    modifier = Modifier.fillMaxHeight()
                )
            }
            composable(route = InterfazCupcakes.Escoger.name) {
                InterfazOpcionSeleccionada(
                    subtotal = estadoUI.precio,
                    clicBotonSiguiente = { controlNav.navigate(InterfazCupcakes.Resumen.name) },
                    clicBotonCancelar = {
                        cancelarPedidoYNavegarInicio(modeloVista, controlNav)
                    },
                    opciones = estadoUI.opcionesElegidas,
                    seleccionCambiada = { modeloVista.establecerFecha(it) },
                    modifier = Modifier.fillMaxHeight()
                )
            }
            composable(route = InterfazCupcakes.Resumen.name) {
                val contexto = LocalContext.current
                InterfazResumenPedido(
                    ordenarEstadoUI = estadoUI,
                    clicBotonCancelar = {
                        cancelarPedidoYNavegarInicio(modeloVista, controlNav)
                    },
                    clicBotonEnviar = { subject: String, summary: String ->
                        compartirPedido(contexto, materia = subject, resumen = summary)
                    },
                    modifier = Modifier.fillMaxHeight()
                )
            }
        }
    }
}

private fun cancelarPedidoYNavegarInicio(
    modeloVista: OrdenModeloVista,
    controlNavegacion: NavHostController
) {
    modeloVista.resetearOrden()
    controlNavegacion.popBackStack(InterfazCupcakes.Iniciar.name, inclusive = false)
}

private fun compartirPedido(contexto: Context, materia: String, resumen: String) {
    val intento = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, materia)
        putExtra(Intent.EXTRA_TEXT, resumen)
    }
    contexto.startActivity(
        Intent.createChooser(
            intento,
            contexto.getString(R.string.nuevo_pedido_cupcake)
        )
    )
}
