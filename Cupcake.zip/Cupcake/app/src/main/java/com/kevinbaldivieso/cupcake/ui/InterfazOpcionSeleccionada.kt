package com.kevinbaldivieso.cupcake.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import com.kevinbaldivieso.cupcake.R
import com.kevinbaldivieso.cupcake.ui.componentes.EtiquetaPrecioFormateada
import com.kevinbaldivieso.cupcake.ui.theme.CupcakeTheme

@Composable
fun InterfazOpcionSeleccionada(
    modifier: Modifier = Modifier,
    subtotal: String,
    opciones: List<String>,
    seleccionCambiada: (String) -> Unit = {},
    clicBotonCancelar: () -> Unit = {},
    clicBotonSiguiente: () -> Unit = {}
) {
    var valorSeleccionado by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.padding(dimensionResource(R.dimen.padding_medium))) {
            opciones.forEach { item ->
                Row(
                    modifier = Modifier.selectable(
                        selected = valorSeleccionado == item,
                        onClick = {
                            valorSeleccionado = item
                            seleccionCambiada(item)
                        }
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = valorSeleccionado == item,
                        onClick = {
                            valorSeleccionado = item
                            seleccionCambiada(item)
                        }
                    )
                    Text(item)
                }
            }
            HorizontalDivider(
                modifier = Modifier.padding(bottom = dimensionResource(R.dimen.padding_medium)),
                thickness = dimensionResource(R.dimen.thickness_divider)
            )
            EtiquetaPrecioFormateada(
                subtotal = subtotal,
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(
                        top = dimensionResource(R.dimen.padding_medium),
                        bottom = dimensionResource(R.dimen.padding_medium)
                    )
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(dimensionResource(R.dimen.padding_medium)),
            horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_medium)),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = clicBotonCancelar
            ) {
                Text(stringResource(R.string.cancelar))
            }
            Button(
                modifier = Modifier.weight(1f),
                // the button is enabled when the user makes a selection
                enabled = valorSeleccionado.isNotEmpty(),
                onClick = clicBotonSiguiente
            ) {
                Text(stringResource(R.string.siguiente))
            }
        }
    }

}

@Preview
@Composable
fun SelectOptionPreview() {
    CupcakeTheme {
        InterfazOpcionSeleccionada(
            subtotal = "299.99",
            opciones = listOf("Option 1", "Option 2", "Option 3", "Option 4"),
            modifier=Modifier.fillMaxHeight()
        )
    }
}
