package com.kevinbaldivieso.cupcake.data

import com.kevinbaldivieso.cupcake.R

object RecursoDatos {
    val sabores = listOf(
        R.string.vainilla,
        R.string.chocolate,
        R.string.terciopelo_rojo,
        R.string.caramelo_salado,
        R.string.cafe
    )

    val cantidadOpciones = listOf(
        Pair(R.string.un_cupcake, 1),
        Pair(R.string.seis_cupcakes, 6),
        Pair(R.string.doce_cupcakes, 12)
    )
}
