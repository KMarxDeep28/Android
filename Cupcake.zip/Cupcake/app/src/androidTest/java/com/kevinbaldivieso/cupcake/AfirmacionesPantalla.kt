package com.kevinbaldivieso.cupcake

import androidx.navigation.NavController
import org.junit.Assert.assertEquals

fun NavController.assertCurrentRouteName(nombreRutaEsperado: String) {
    assertEquals(nombreRutaEsperado,currentBackStackEntry?.destination?.route)
}