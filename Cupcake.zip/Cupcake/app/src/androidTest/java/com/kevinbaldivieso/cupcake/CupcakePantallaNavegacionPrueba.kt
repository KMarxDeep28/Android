package com.kevinbaldivieso.cupcake

import android.icu.util.Calendar
import androidx.activity.ComponentActivity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Locale

class CupcakePantallaNavegacionPrueba {
    @get:Rule
    val composeReglaPrueba = createAndroidComposeRule<ComponentActivity>()

    private lateinit var controlNav: TestNavHostController

    @Before
    fun configurarCupcakeNavAnfitrion() {
        composeReglaPrueba.setContent {
            controlNav = TestNavHostController(LocalContext.current).apply {
                navigatorProvider.addNavigator(ComposeNavigator())
            }
            CupcakeApp(controlNav = controlNav)
        }
    }

    @Test
    fun cupcakeNavAnfitrion_VerificarDestinoInicio() {
        //assertEquals(InterfazCupcakes.Iniciar.name, controlNav.currentBackStackEntry?.destination?.route)
        controlNav.assertCurrentRouteName(InterfazCupcakes.Iniciar.name)
    }

    @Test
    fun cupcakeNavAnfitrion_VerificarNoMostrarNavegaciuonHaciaAtras() {
        val textoAtras = composeReglaPrueba.activity.getString(R.string.boton_atras)
        composeReglaPrueba.onNodeWithContentDescription(textoAtras).assertDoesNotExist()
    }

    @Test
    fun cupcakeNavAnfitrion_ClicUnCupcake_NavegaPantallaSeleccionSabor() {
        composeReglaPrueba.onNodeWithStringId(R.string.un_cupcake).performClick()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Sabor.name)
    }

    @Test
    fun cupcakeNavAnfitrion_ClicSiguienteSaborPantalla_NavElegirPantalla() {
        navegarSaborPantalla()
        composeReglaPrueba.onNodeWithStringId(R.string.siguiente)
            .performClick()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Escoger.name)
    }

    @Test
    fun cupcakeNavHost_clickBackOnFlavorScreen_navigatesToStartOrderScreen() {
        navegarSaborPantalla()
        navegarHaciaArriba()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Iniciar.name)
    }

    @Test
    fun cupcakeNavHost_clickCancelOnFlavorScreen_navigatesToStartOrderScreen() {
        navegarSaborPantalla()
        composeReglaPrueba.onNodeWithStringId(R.string.cancelar)
            .performClick()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Iniciar.name)
    }

    @Test
    fun cupcakeNavHost_clickNextOnPickupScreen_navigatesToSummaryScreen() {
        navegarEscogerPantalla()
        composeReglaPrueba.onNodeWithText(obtenerFechaFormato())
            .performClick()
        composeReglaPrueba.onNodeWithStringId(R.string.siguiente)
            .performClick()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Resumen.name)
    }

    @Test
    fun cupcakeNavHost_clickBackOnPickupScreen_navigatesToFlavorScreen() {
        navegarEscogerPantalla()
        navegarHaciaArriba()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Sabor.name)
    }

    @Test
    fun cupcakeNavHost_clickCancelOnPickupScreen_navigatesToStartOrderScreen() {
        navegarEscogerPantalla()
        composeReglaPrueba.onNodeWithStringId(R.string.cancelar)
            .performClick()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Iniciar.name)
    }

    @Test
    fun cupcakeNavHost_clickCancelOnSummaryScreen_navigatesToStartOrderScreen() {
        navegarPantallaResumen()
        composeReglaPrueba.onNodeWithStringId(R.string.cancelar)
            .performClick()
        controlNav.assertCurrentRouteName(InterfazCupcakes.Iniciar.name)
    }

    private fun navegarSaborPantalla() {
        composeReglaPrueba.onNodeWithStringId(R.string.un_cupcake).performClick()
        composeReglaPrueba.onNodeWithStringId(R.string.chocolate).performClick()
    }

    private fun obtenerFechaFormato(): String {
        val calendario = Calendar.getInstance()
        calendario.add(Calendar.DATE, 1)
        val formato = SimpleDateFormat("E MMM d", Locale.getDefault())
        return formato.format(calendario.time)
    }

    private fun navegarEscogerPantalla() {
        navegarSaborPantalla()
        composeReglaPrueba.onNodeWithStringId(R.string.siguiente)
            .performClick()
    }

    private fun navegarPantallaResumen() {
        navegarEscogerPantalla()
        composeReglaPrueba.onNodeWithText(obtenerFechaFormato())
            .performClick()
        composeReglaPrueba.onNodeWithStringId(R.string.siguiente)
            .performClick()
    }

    private fun navegarHaciaArriba() {
        val textoAtras = composeReglaPrueba.activity.getString(R.string.boton_atras)
        composeReglaPrueba.onNodeWithContentDescription(textoAtras).performClick()
    }
}