package com.kevinbaldivieso.cupcake

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.kevinbaldivieso.cupcake.ui.InterfazOpcionSeleccionada
import org.junit.Rule
import org.junit.Test

class CupcakePantallaPedidoPrueba {
    @get:Rule
    val composeReglaPrueba = createAndroidComposeRule<ComponentActivity>()

    @Test
    fun pantallaSeleccionOpciones_VerificarContenido() {
        val sabores= listOf("Vainilla","Chocolate","Hazelnut","Cookie","Mango")
        val subtotal="$100"

        composeReglaPrueba.setContent {
            InterfazOpcionSeleccionada(subtotal = subtotal, opciones = sabores)
        }
        sabores.forEach{sabor ->
            composeReglaPrueba.onNodeWithText(sabor).assertIsDisplayed()
        }

        composeReglaPrueba.onNodeWithText(
            composeReglaPrueba.activity.getString(
                R.string.subtotal_precio,
                subtotal
            )
        ).assertIsDisplayed()

        composeReglaPrueba.onNodeWithStringId(R.string.siguiente).assertIsNotEnabled()
    }
}