package com.kevinbaldivieso.tarjetadepresentacion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.kevinbaldivieso.tarjetadepresentacion.ui.theme.TarjetaDEpresentacionTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TarjetaDEpresentacionTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Tarjeta(stringResource(R.string.Titulo),
                        stringResource(R.string.Subtitulo),
                        stringResource(R.string.Telefono),
                        stringResource(R.string.Compartido),
                        stringResource(R.string.Correo))
                }
            }
        }
    }
}

@Composable
fun Tarjeta(titulo: String, subtitulo: String, telefono: String, compartido: String, correo: String) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
            .background(Color.LightGray)//Encontra color
        ,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ){
        val image = painterResource(R.drawable.android_logo)
        Image(
            painter = image,
            contentDescription = null,
            modifier = Modifier
                .height(120.dp)
                .width(150.dp))
        Text(
            text = titulo,
            color = Color.White
        )
        Text(
            text = subtitulo,
            color = Color(0xFF3ddc84)
        )
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 500.dp)
            .padding(bottom = 70.dp)
        ,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ){
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp),
            ){
            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = null,
                modifier = Modifier.padding(start = 60.dp),
                Color(0xFF3ddc84)
            )
            Text(
                text = telefono,
                modifier = Modifier
                    .padding(start = 25.dp),
                color = Color.White
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp),
        ){

            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = null,
                modifier = Modifier
                    .padding(start = 60.dp),
                Color(0xFF3ddc84))
            Text(
                text = compartido,
                modifier = Modifier
                    .padding(start = 25.dp),
                color = Color.White)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp),
        ){
            Icon(
                imageVector = Icons.Default.Email,
                contentDescription = null,
                modifier = Modifier
                    .padding(start = 60.dp),
                Color(0xFF3ddc84) )
            Text(
                text = correo,
                modifier = Modifier
                    .padding(start = 25.dp),
                color = Color.White)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun TarjetaPreview() {
    TarjetaDEpresentacionTheme {
        Tarjeta(stringResource(R.string.Titulo),
            stringResource(R.string.Subtitulo),
            stringResource(R.string.Telefono),
            stringResource(R.string.Compartido),
            stringResource(R.string.Correo))
    }
}