package com.kevinbaldivieso.cuadriculacursos.modelo

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Materias(
    @StringRes val nombreId: Int,
    val puntosId: Int,
    @DrawableRes val imagenId: Int
)
