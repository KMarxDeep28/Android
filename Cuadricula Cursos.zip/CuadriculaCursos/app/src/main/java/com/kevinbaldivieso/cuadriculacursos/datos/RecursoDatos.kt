package com.kevinbaldivieso.cuadriculacursos.datos

import com.kevinbaldivieso.cuadriculacursos.R
import com.kevinbaldivieso.cuadriculacursos.modelo.Materias

object RecursoDatos {
    val materias = listOf(
        Materias(R.string.arquitectura, 58, R.drawable.architecture),
        Materias(R.string.automotriz, 30, R.drawable.automotive),
        Materias(R.string.biologia, 90, R.drawable.biology),
        Materias(R.string.artesania, 121, R.drawable.crafts),
        Materias(R.string.negocio, 78, R.drawable.business),
        Materias(R.string.culinaria, 118, R.drawable.culinary),
        Materias(R.string.disenio, 423, R.drawable.design),
        Materias(R.string.ecologia, 28, R.drawable.ecology),
        Materias(R.string.ingenieria, 67, R.drawable.engineering),
        Materias(R.string.moda, 92, R.drawable.fashion),
        Materias(R.string.finanzas, 100, R.drawable.finance),
        Materias(R.string.cine, 165, R.drawable.film),
        Materias(R.string.jugadosVideojuego, 37, R.drawable.gaming),
        Materias(R.string.geologia, 290, R.drawable.geology),
        Materias(R.string.dibujo, 326, R.drawable.drawing),
        Materias(R.string.historia, 189, R.drawable.history),
        Materias(R.string.periodismo, 96, R.drawable.journalism),
        Materias(R.string.leyes, 58, R.drawable.law),
        Materias(R.string.estiloVida, 305, R.drawable.lifestyle),
        Materias(R.string.musica, 212, R.drawable.music),
        Materias(R.string.pintura, 172, R.drawable.painting),
        Materias(R.string.fotografia, 321, R.drawable.photography),
        Materias(R.string.fisica, 41, R.drawable.physics),
        Materias(R.string.tecnologia, 118, R.drawable.tech),
    )
}