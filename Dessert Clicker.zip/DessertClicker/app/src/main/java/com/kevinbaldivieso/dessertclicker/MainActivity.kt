package com.kevinbaldivieso.dessertclicker

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.content.ContextCompat
import com.kevinbaldivieso.dessertclicker.datos.PostreUIEstado
import com.kevinbaldivieso.dessertclicker.ui.PostresViewModel
import com.kevinbaldivieso.dessertclicker.ui.theme.DessertClickerTheme

private const val Etiqueta = "MainActivity"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(Etiqueta, "onCreate Llamado")
        setContent {
            DessertClickerTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding(),
                ) {
                    PostreViewModel()
                    //DessertClickerApp(postres = RecursoDatos.postreLista)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(Etiqueta, "onStart Llamado")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(Etiqueta, "onRestart Llamado")

    }

    override fun onResume() {
        super.onResume()
        Log.d(Etiqueta, "onResume Llamado")
    }

    override fun onPause() {
        super.onPause()
        Log.d(Etiqueta, "onPause Llamado")
    }

    override fun onStop() {
        super.onStop()
        Log.d(Etiqueta, "onStop Llamado")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(Etiqueta, "onDestroy Llamado")
    }
}

/*fun determinarPostreMostrar(
    postres: List<Postre>,
    postreVendido: Int
): Postre {
    var postreAMostrar = postres.first()
    for (postre in postres) {
        if (postreVendido >= postre.inicioMontoProduccion) {
            postreAMostrar = postre
        } else {
            break
        }
    }
    return postreAMostrar
}*/

private fun compartirInformacionVentaPostre(
    intentoContexto: Context,
    postreVenta: Int,
    ganancia: Int
) {
    val enviarIntencion = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(
            Intent.EXTRA_TEXT,
            intentoContexto.getString(R.string.texto_compartir, postreVenta, ganancia)
        )
        type = "texto sin formato"
    }

    val compartirIntento = Intent.createChooser(enviarIntencion, null)

    try {
        ContextCompat.startActivity(intentoContexto, compartirIntento, null)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(
            intentoContexto,
            intentoContexto.getString(R.string.compartir_no_disponible),
            Toast.LENGTH_LONG
        ).show()
    }
}

@Composable
fun PostreViewModel(
    modeloVista: PostresViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val estadoUIAux by modeloVista.estadoPostreUI.collectAsState()
    DessertClickerApp(
        estadoUI = estadoUIAux,
        click = modeloVista::postreClick
    )
}

@Composable
private fun DessertClickerApp(
    estadoUI: PostreUIEstado,
    click: () -> Unit
    //postres: List<Postre>
) {

    /*var ganancia by rememberSaveable { mutableIntStateOf(0) }
    var postreVendido by rememberSaveable { mutableIntStateOf(0) }
    val postreActualIndice by rememberSaveable { mutableIntStateOf(0) }
    var postreActualPrecio by rememberSaveable {
        mutableIntStateOf(postres[postreActualIndice].precio)
    }
    var postreActualImagenId by rememberSaveable {
        mutableIntStateOf(postres[postreActualIndice].imagendId)
    }*/

    Scaffold(
        topBar = {
            val intentoContexto = LocalContext.current
            val direccionDisenio = LocalLayoutDirection.current
            DessertClickerAppBarraSuperior(
                botonCompartirClicked = {
                    compartirInformacionVentaPostre(
                        intentoContexto = intentoContexto,
                        postreVenta = estadoUI.postreVendidoActual,//postreVendido,
                        ganancia = estadoUI.gananciaActual//ganancia
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        start = WindowInsets.safeDrawing
                            .asPaddingValues()
                            .calculateStartPadding(direccionDisenio),
                        end = WindowInsets.safeDrawing
                            .asPaddingValues()
                            .calculateEndPadding(direccionDisenio),
                    )
                    .background(MaterialTheme.colorScheme.primary)
            )
        }
    ) { contentPadding ->
        DessertClickerPantalla(
            ganancia = estadoUI.gananciaActual,//ganancia,
            postreVendido = estadoUI.postreVendidoActual,//postreVendido,
            postreImagenId = estadoUI.imagenIDActualPostre,//postreActualImagenId,
            postreClicked = click,/*{

                // Update the revenue
                ganancia += postreActualPrecio
                postreVendido++

                // Show the next dessert
                val dessertToShow = determinarPostreMostrar(postres, postreVendido)
                postreActualImagenId = dessertToShow.imagendId
                postreActualPrecio = dessertToShow.precio
            },*/
            modifier = Modifier.padding(contentPadding)
        )
    }
}

@Composable
private fun DessertClickerAppBarraSuperior(
    botonCompartirClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = stringResource(R.string.app_name),
            modifier = Modifier.padding(start = dimensionResource(R.dimen.padding_medium)),
            color = MaterialTheme.colorScheme.onPrimary,
            style = MaterialTheme.typography.titleLarge,
        )
        IconButton(
            onClick = botonCompartirClicked,
            modifier = Modifier.padding(end = dimensionResource(R.dimen.padding_medium)),
        ) {
            Icon(
                imageVector = Icons.Filled.Share,
                contentDescription = stringResource(R.string.compartir),
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}

@Composable
fun DessertClickerPantalla(
    ganancia: Int,
    postreVendido: Int,
    @DrawableRes postreImagenId: Int,
    postreClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        Image(
            painter = painterResource(R.drawable.bakery_back),
            contentDescription = null,
            contentScale = ContentScale.Crop
        )
        Column {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                Image(
                    painter = painterResource(postreImagenId),
                    contentDescription = null,
                    modifier = Modifier
                        .width(dimensionResource(R.dimen.image_size))
                        .height(dimensionResource(R.dimen.image_size))
                        .align(Alignment.Center)
                        .clickable { postreClicked() },
                    contentScale = ContentScale.Crop,
                )
            }
            InformacionTransaccion(
                ganancia = ganancia,
                postreVendido = postreVendido,
                modifier = Modifier.background(MaterialTheme.colorScheme.secondaryContainer)
            )
        }
    }
}

@Composable
private fun InformacionTransaccion(
    ganancia: Int,
    postreVendido: Int,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        PostreVendidoInformacion(
            postreVendido = postreVendido,
            modifier = Modifier
                .fillMaxWidth()
                .padding(dimensionResource(R.dimen.padding_medium))
        )
        InfromacionGanancia(
            ganancia = ganancia,
            modifier = Modifier
                .fillMaxWidth()
                .padding(dimensionResource(R.dimen.padding_medium))
        )
    }
}

@Composable
private fun InfromacionGanancia(ganancia: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = stringResource(R.string.ganancia_total),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
        Text(
            text = "$${ganancia}",
            textAlign = TextAlign.Right,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

@Composable
private fun PostreVendidoInformacion(postreVendido: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = stringResource(R.string.postre_vendido),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
        Text(
            text = postreVendido.toString(),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

@Preview
@Composable
fun MyDessertClickerAppPreview() {
    DessertClickerTheme {
        PostreViewModel()
        //DessertClickerApp(listOf(Postre(R.drawable.cupcake, 5, 0)))
    }
}