package com.kevinbaldivieso.dessertclicker.datos

import androidx.annotation.DrawableRes
import com.kevinbaldivieso.dessertclicker.datos.RecursoDatos.postreLista

data class PostreUIEstado (
    val indicePostreActual: Int = 0,
    val postreVendidoActual: Int=0,
    val gananciaActual: Int=0,
    val precioActualPostre: Int= postreLista[indicePostreActual].precio,
    @DrawableRes val imagenIDActualPostre: Int=postreLista[indicePostreActual].imagendId
)