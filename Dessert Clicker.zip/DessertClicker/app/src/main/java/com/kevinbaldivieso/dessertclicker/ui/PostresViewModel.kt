package com.kevinbaldivieso.dessertclicker.ui

import androidx.lifecycle.ViewModel
import com.kevinbaldivieso.dessertclicker.datos.PostreUIEstado
import com.kevinbaldivieso.dessertclicker.datos.RecursoDatos.postreLista
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class PostresViewModel : ViewModel() {
    private val estadoUI0 = MutableStateFlow(PostreUIEstado())
    val estadoPostreUI: StateFlow<PostreUIEstado> = estadoUI0.asStateFlow()

    fun postreClick() {
        estadoUI0.update { item ->
            val indiceSiguiente = determinarIndices(item.postreVendidoActual + 1)
            item.copy(
                indicePostreActual = indiceSiguiente,
                gananciaActual = item.gananciaActual + item.precioActualPostre,
                postreVendidoActual = item.postreVendidoActual + 1,
                imagenIDActualPostre = postreLista[indiceSiguiente].imagendId,
                precioActualPostre = postreLista[indiceSiguiente].precio
            )
        }
    }

    private fun determinarIndices(postreVendido: Int): Int {
        var indiceAux = 0
        for (item in postreLista.indices) {
            if (postreVendido >= postreLista[item].inicioMontoProduccion) {
                indiceAux = item
            }
        }
        return indiceAux
    }
}