package com.kevinbaldivieso.superheroes.modelo

import com.kevinbaldivieso.superheroes.R

object RepositorioHeroes {
    val heroes = listOf(
        Heroe(
            nombreHeroe = R.string.hero1,
            descripcionHeroe = R.string.description1,
            imagenHeroe = R.drawable.android_superhero1
        ),
        Heroe(
            nombreHeroe = R.string.hero2,
            descripcionHeroe = R.string.description2,
            imagenHeroe = R.drawable.android_superhero2
        ),
        Heroe(
            nombreHeroe = R.string.hero3,
            descripcionHeroe = R.string.description3,
            imagenHeroe = R.drawable.android_superhero3
        ),
        Heroe(
            nombreHeroe = R.string.hero4,
            descripcionHeroe = R.string.description4,
            imagenHeroe = R.drawable.android_superhero4
        ),
        Heroe(
            nombreHeroe = R.string.hero5,
            descripcionHeroe = R.string.description5,
            imagenHeroe = R.drawable.android_superhero5
        ),
        Heroe(
            nombreHeroe = R.string.hero6,
            descripcionHeroe = R.string.description6,
            imagenHeroe = R.drawable.android_superhero6
        )
    )
}