package com.kevinbaldivieso.superheroes.modelo

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Heroe(
    @StringRes val nombreHeroe: Int,
    @StringRes val descripcionHeroe: Int,
    @DrawableRes val imagenHeroe: Int
)
