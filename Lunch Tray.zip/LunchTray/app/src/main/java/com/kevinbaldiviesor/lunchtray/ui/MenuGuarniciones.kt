package com.kevinbaldiviesor.lunchtray.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.tooling.preview.Preview
import com.kevinbaldiviesor.lunchtray.datos.RecursoDatos
import com.kevinbaldiviesor.lunchtray.model.MenuItem
import com.kevinbaldiviesor.lunchtray.R

@Composable
fun MenuGuarniciones(
    opciones: List<MenuItem.SideDishItem>,
    clicBotonCancelar: () -> Unit,
    clicBotonSiguiente: () -> Unit,
    cambioSeleccion: (MenuItem.SideDishItem) -> Unit,
    modifier: Modifier = Modifier
) {
    BaseMenuScreen(
        opciones = opciones,
        clicBotonCancelar = clicBotonCancelar,
        clicBotonSiguiente = clicBotonSiguiente,
        cambioSeleccion = cambioSeleccion as (MenuItem) -> Unit,
        modifier = modifier
    )
}

@Preview
@Composable
fun MenuGuarnicionesPreview(){
    MenuGuarniciones(
        opciones = RecursoDatos.guarnicionesMenuItems,
        clicBotonSiguiente = {},
        clicBotonCancelar = {},
        cambioSeleccion = {},
        modifier = Modifier
            .padding(dimensionResource(R.dimen.padding_medium))
            .verticalScroll(rememberScrollState())
    )
}
