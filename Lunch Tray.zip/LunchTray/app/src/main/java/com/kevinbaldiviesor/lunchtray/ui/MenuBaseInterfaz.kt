package com.kevinbaldiviesor.lunchtray.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import com.kevinbaldiviesor.lunchtray.model.MenuItem
import com.kevinbaldiviesor.lunchtray.R

@Composable
fun BaseMenuScreen(
    opciones: List<MenuItem>,
    modifier: Modifier = Modifier,
    clicBotonCancelar: () -> Unit = {},
    clicBotonSiguiente: () -> Unit = {},
    cambioSeleccion: (MenuItem) -> Unit,
) {

    var nombreItemSeleccionado by rememberSaveable { mutableStateOf("") }

    Column(modifier = modifier) {
        opciones.forEach { item ->
            val onClick = {
                nombreItemSeleccionado = item.nombre
                cambioSeleccion(item)
            }
            MenuItemRow(
                item = item,
                nombreItemSeleccionado = nombreItemSeleccionado,
                clic = onClick,
                modifier = Modifier.selectable(
                    selected = nombreItemSeleccionado == item.nombre,
                    onClick = onClick
                )
                    .padding(
                        start = dimensionResource(R.dimen.padding_medium),
                        end = dimensionResource(R.dimen.padding_medium),
                    )
            )
        }

        MenuScreenButtonGroup(
            nombreItemSeleccionado = nombreItemSeleccionado,
            clicBotonCancelar = clicBotonCancelar,
            clicBotonSiguiente = {
                // Assert not null bc next button is not enabled unless selectedItem is not null.
                clicBotonSiguiente()
            },
            modifier = Modifier.fillMaxWidth().padding(dimensionResource(R.dimen.padding_medium))
        )
    }
}

@Composable
fun MenuItemRow(
    item: MenuItem,
    nombreItemSeleccionado: String,
    clic: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = nombreItemSeleccionado == item.nombre,
            onClick = clic
        )
        Column(
            verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_small))
        ) {
            Text(
                text = item.nombre,
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                text = item.descripcion,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = item.getFormattedPrice(),
                style = MaterialTheme.typography.bodyMedium
            )
            Divider(
                thickness = dimensionResource(R.dimen.thickness_divider),
                modifier = Modifier.padding(bottom = dimensionResource(R.dimen.padding_medium))
            )
        }
    }
}

@Composable
fun MenuScreenButtonGroup(
    nombreItemSeleccionado: String,
    clicBotonCancelar: () -> Unit,
    clicBotonSiguiente: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_medium))
    ){
        OutlinedButton(modifier = Modifier.weight(1f), onClick = clicBotonCancelar) {
            Text(stringResource(R.string.cancel).uppercase())
        }
        Button(
            modifier = Modifier.weight(1f),
            // the button is enabled when the user makes a selection
            enabled = nombreItemSeleccionado.isNotEmpty(),
            onClick = clicBotonSiguiente
        ) {
            Text(stringResource(R.string.next).uppercase())
        }
    }
}
