package com.kevinbaldiviesor.lunchtray.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import com.kevinbaldiviesor.lunchtray.datos.RecursoDatos
import com.kevinbaldiviesor.lunchtray.model.MenuItem
import com.kevinbaldiviesor.lunchtray.model.PedidoEstadoUI
import com.kevinbaldiviesor.lunchtray.R

@Composable
fun VerPantalla(
    pedidoEstadoUI: PedidoEstadoUI,
    botonSiguienteClic: () -> Unit,
    botonCancelarClic: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_small))
    ) {
        Text(
            text = stringResource(R.string.order_summary),
            fontWeight = FontWeight.Bold
        )
        ResumenItem(item = pedidoEstadoUI.entrada, modifier = Modifier.fillMaxWidth())
        ResumenItem(item = pedidoEstadoUI.guarnicion, modifier = Modifier.fillMaxWidth())
        ResumenItem(item = pedidoEstadoUI.acompaniamiento, modifier = Modifier.fillMaxWidth())

        Divider(
            thickness = dimensionResource(R.dimen.thickness_divider),
            modifier = Modifier.padding(bottom = dimensionResource(R.dimen.padding_small))
        )

        PedidoSubCost(
            resourceId = R.string.subtotal,
            precio = pedidoEstadoUI.itemPrecioTotal.formatPrice(),
            Modifier.align(Alignment.End)
        )

        PedidoSubCost(
            resourceId = R.string.tax,
            precio = pedidoEstadoUI.pedidoImpuesto.formatPrice(),
            Modifier.align(Alignment.End)
        )

        Text(
            text = stringResource(R.string.total, pedidoEstadoUI.pedidoPrecioTotal.formatPrice()),
            modifier = Modifier.align(Alignment.End),
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(dimensionResource(R.dimen.padding_medium)),
            horizontalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_medium))
        ){
            OutlinedButton(modifier = Modifier.weight(1f), onClick = botonCancelarClic) {
                Text(stringResource(R.string.cancel).uppercase())
            }
            Button(
                modifier = Modifier.weight(1f),
                onClick = botonSiguienteClic
            ) {
                Text(stringResource(R.string.submit).uppercase())
            }
        }
    }
}

@Composable
fun ResumenItem(
    item: MenuItem?,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(item?.nombre ?: "")
        Text(item?.getFormattedPrice() ?: "")
    }
}

@Composable
fun PedidoSubCost(
    @StringRes resourceId: Int,
    precio: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = stringResource(resourceId, precio),
        modifier = modifier
    )
}

@Preview
@Composable
fun VerPantallaPreview() {
    VerPantalla(
        pedidoEstadoUI = PedidoEstadoUI(
            entrada = RecursoDatos.entradaMenuItems[0],
            guarnicion = RecursoDatos.guarnicionesMenuItems[0],
            acompaniamiento = RecursoDatos.acompaniamientoMenuItems[0],
            itemPrecioTotal = 15.00,
            pedidoImpuesto = 1.00,
            pedidoPrecioTotal = 16.00
        ),
        botonSiguienteClic = {},
        botonCancelarClic = {},
        modifier = Modifier
            .padding(dimensionResource(R.dimen.padding_medium))
            .verticalScroll(rememberScrollState())
    )
}
