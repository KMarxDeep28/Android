package com.kevinbaldiviesor.lunchtray.ui

import androidx.lifecycle.ViewModel
import com.kevinbaldiviesor.lunchtray.model.MenuItem
import com.kevinbaldiviesor.lunchtray.model.PedidoEstadoUI
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.NumberFormat

class PedidoModeloVista : ViewModel() {

    private val tasaImpuesto = 0.08

    private val _estadoUI = MutableStateFlow(PedidoEstadoUI())
    val estadoUI: StateFlow<PedidoEstadoUI> = _estadoUI.asStateFlow()

    fun actualizarEntrada(entrada: MenuItem.EntreeItem) {
        val previousEntree = _estadoUI.value.entrada
        actualizarItem(entrada, previousEntree)
    }

    fun actualizarGuarnicion(sideDish: MenuItem.SideDishItem) {
        val previousSideDish = _estadoUI.value.guarnicion
        actualizarItem(sideDish, previousSideDish)
    }

    fun actualizarAcompaniamiento(accompaniment: MenuItem.AccompanimentItem) {
        val previousAccompaniment = _estadoUI.value.acompaniamiento
        actualizarItem(accompaniment, previousAccompaniment)
    }

    fun resetearPedido() {
        _estadoUI.value = PedidoEstadoUI()
    }

    private fun actualizarItem(newItem: MenuItem, previousItem: MenuItem?) {
        _estadoUI.update { currentState ->
            val previousItemPrice = previousItem?.precio ?: 0.0
            // subtract previous item price in case an item of this category was already added.
            val itemTotalPrice = currentState.itemPrecioTotal - previousItemPrice + newItem.precio
            // recalculate tax
            val tax = itemTotalPrice * tasaImpuesto
            currentState.copy(
                itemPrecioTotal = itemTotalPrice,
                pedidoImpuesto = tax,
                pedidoPrecioTotal = itemTotalPrice + tax,
                entrada = if (newItem is MenuItem.EntreeItem) newItem else currentState.entrada,
                guarnicion = if (newItem is MenuItem.SideDishItem) newItem else currentState.guarnicion,
                acompaniamiento =
                    if (newItem is MenuItem.AccompanimentItem) newItem else currentState.acompaniamiento
            )
        }
    }
}

fun Double.formatPrice(): String {
    return NumberFormat.getCurrencyInstance().format(this)
}
