package com.kevinbaldiviesor.lunchtray.model

import java.text.NumberFormat

sealed class MenuItem(
    open val nombre: String,
    open val descripcion: String,
    open val precio: Double
) {
    data class EntreeItem(
        override val nombre: String,
        override val descripcion: String,
        override val precio: Double
    ) : MenuItem(nombre, descripcion, precio)

    data class SideDishItem(
        override val nombre: String,
        override val descripcion: String,
        override val precio: Double
    ) : MenuItem(nombre, descripcion, precio)

    data class AccompanimentItem(
        override val nombre: String,
        override val descripcion: String,
        override val precio: Double
    ) : MenuItem(nombre, descripcion, precio)

    fun getFormattedPrice(): String = NumberFormat.getCurrencyInstance().format(precio)
}
