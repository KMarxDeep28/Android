package com.kevinbaldiviesor.lunchtray

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kevinbaldiviesor.lunchtray.datos.RecursoDatos
import com.kevinbaldiviesor.lunchtray.ui.AcompaniamientoInterfaz
import com.kevinbaldiviesor.lunchtray.ui.VerPantalla
import com.kevinbaldiviesor.lunchtray.ui.InterfazMenuEntrada
import com.kevinbaldiviesor.lunchtray.ui.PedidoModeloVista
import com.kevinbaldiviesor.lunchtray.ui.MenuGuarniciones
import com.kevinbaldiviesor.lunchtray.ui.EmpezarPedidoPantalla

enum class LunchTrayScreen(@StringRes val titulo: Int) {
    Iniciar(titulo = R.string.app_name),
    Entrada(titulo = R.string.choose_entree),
    Guarnicion(titulo = R.string.choose_side_dish),
    Acompaniamiento(titulo = R.string.choose_accompaniment),
    VerPedido(titulo = R.string.order_checkout)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LunchTrayBarraSuperior(
    @StringRes currentScreenTitle: Int,
    poderNavegarAtras: Boolean,
    navegarArriba: () -> Unit,
    modifier: Modifier = Modifier
) {
    CenterAlignedTopAppBar(
        title = { Text(stringResource(currentScreenTitle)) },
        modifier = modifier,
        navigationIcon = {
            if (poderNavegarAtras) {
                IconButton(onClick = navegarArriba) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.back_button)
                    )
                }
            }
        }
    )
}

@Composable
fun LunchTrayApp() {
    val navControl = rememberNavController()

    val entradaPilaAtras by navControl.currentBackStackEntryAsState()

    val pantallaActual = LunchTrayScreen.valueOf(
        entradaPilaAtras?.destination?.route ?: LunchTrayScreen.Iniciar.name
    )

    val modeloVista: PedidoModeloVista = viewModel()

    val estadoUI by modeloVista.estadoUI.collectAsState()

    Scaffold(
        topBar = {
            LunchTrayBarraSuperior(
                currentScreenTitle = pantallaActual.titulo,
                poderNavegarAtras = navControl.previousBackStackEntry != null,
                navegarArriba = { navControl.navigateUp() }
            )
        }
    ) { innerPadding ->

        NavHost(
            navController = navControl,
            startDestination = LunchTrayScreen.Iniciar.name,
        ) {
            composable(route = LunchTrayScreen.Iniciar.name) {
                EmpezarPedidoPantalla(
                    empezarPedidoClic = {
                        navControl.navigate(LunchTrayScreen.Entrada.name)
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }

            composable(route = LunchTrayScreen.Entrada.name) {
                InterfazMenuEntrada(
                    opciones = RecursoDatos.entradaMenuItems,
                    clicBotonCancelar = {
                        modeloVista.resetearPedido()
                        navControl.popBackStack(LunchTrayScreen.Iniciar.name, inclusive = false)
                    },
                    clicBotonSiguiente = {
                        navControl.navigate(LunchTrayScreen.Guarnicion.name)
                    },
                    cambioSeleccion = { item ->
                        modeloVista.actualizarEntrada(item)
                    },
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(innerPadding)
                )
            }

            composable(route = LunchTrayScreen.Guarnicion.name) {
                MenuGuarniciones(
                    opciones = RecursoDatos.guarnicionesMenuItems,
                    clicBotonCancelar = {
                        modeloVista.resetearPedido()
                        navControl.popBackStack(LunchTrayScreen.Iniciar.name, inclusive = false)
                    },
                    clicBotonSiguiente = {
                        navControl.navigate(LunchTrayScreen.Acompaniamiento.name)
                    },
                    cambioSeleccion = { item ->
                        modeloVista.actualizarGuarnicion(item)
                    },
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(innerPadding)
                )
            }

            composable(route = LunchTrayScreen.Acompaniamiento.name) {
                AcompaniamientoInterfaz(
                    opciones = RecursoDatos.acompaniamientoMenuItems,
                    clicBotonCancelar = {
                        modeloVista.resetearPedido()
                        navControl.popBackStack(LunchTrayScreen.Iniciar.name, inclusive = false)
                    },
                    clicBotonSiguiente = {
                        navControl.navigate(LunchTrayScreen.VerPedido.name)
                    },
                    cambioSeleccion = { item ->
                        modeloVista.actualizarAcompaniamiento(item)
                    },
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(innerPadding)
                )
            }

            composable(route = LunchTrayScreen.VerPedido.name) {
                VerPantalla(
                    pedidoEstadoUI = estadoUI,
                    botonCancelarClic = {
                        modeloVista.resetearPedido()
                        navControl.popBackStack(LunchTrayScreen.Iniciar.name, inclusive = false)
                    },
                    botonSiguienteClic = {
                        modeloVista.resetearPedido()
                        navControl.popBackStack(LunchTrayScreen.Iniciar.name, inclusive = false)
                    },
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(
                            top = innerPadding.calculateTopPadding(),
                            bottom = innerPadding.calculateBottomPadding(),
                            start = dimensionResource(R.dimen.padding_medium),
                            end = dimensionResource(R.dimen.padding_medium),
                        )
                )
            }
        }
    }
}