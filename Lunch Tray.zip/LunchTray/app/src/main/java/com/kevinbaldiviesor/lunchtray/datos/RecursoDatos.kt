package com.kevinbaldiviesor.lunchtray.datos

import com.kevinbaldiviesor.lunchtray.model.MenuItem

object RecursoDatos {

    val entradaMenuItems = listOf(
        MenuItem.EntreeItem(
            nombre = "Coliflor",
            descripcion = "Coliflor entera, en salmuera, asada y frita",
            precio = 7.00,
        ),
        MenuItem.EntreeItem(
            nombre = "Chili de Tres Frijoles",
            descripcion = "Frijoles negros, frijoles rojos, frijoles rojos, cocidos lentamente, cubiertos con cebolla",
            precio = 4.00,
        ),
        MenuItem.EntreeItem(
            nombre = "Pasta de Champiñones",
            descripcion = "Pasta penne, champiñones, albahaca, con tomates ciruela cocidos en ajo " +
                    "y aceite de oliva",
            precio = 5.50,
        ),
        MenuItem.EntreeItem(
            nombre = "Sartén de Frijoles Negros Picantes",
            descripcion = "Verduras de temporada, frijoles negros, mezcla de especias casera, servidas con " +
                    "aguacate y cebolla rápida en escabeche",
            precio = 5.50,
        )
    )

    val guarnicionesMenuItems = listOf(
        MenuItem.SideDishItem(
            nombre = "Ensalada de Verano",
            descripcion = "Tomates de herencia, lechuga mantecosa, duraznos, aguacate, aderezo balsámico",
            precio = 2.50,
        ),
        MenuItem.SideDishItem(
            nombre = "Sopa de Calabaza Moscada",
            descripcion = "Calabaza moscada asada, pimientos asados, aceite de chile",
            precio = 3.00,
        ),
        MenuItem.SideDishItem(
            nombre = "Papas Picantes",
            descripcion = "Papas marmoladas, asadas y fritas en mezcla de especias casera",
            precio = 2.00,
        ),
        MenuItem.SideDishItem(
            nombre = "Arroz de Coco",
            descripcion = "Arroz, leche de coco, lima y azúcar",
            precio = 1.50,
        )
    )

    val acompaniamientoMenuItems = listOf(
        MenuItem.AccompanimentItem(
            nombre = "Pan de Almuerzo",
            descripcion = "Pan recién horneado hecho en casa",
            precio = 0.50,
        ),
        MenuItem.AccompanimentItem(
            nombre = "Bayas Variadas",
            descripcion = "Fresas, arándanos, frambuesas y moras",
            precio = 1.00,
        ),
        MenuItem.AccompanimentItem(
            nombre = "Vegetales en Escabeche",
            descripcion = "Pepinos y zanahorias en escabeche, hechos en casa",
            precio = 0.50,
        )
    )
}
