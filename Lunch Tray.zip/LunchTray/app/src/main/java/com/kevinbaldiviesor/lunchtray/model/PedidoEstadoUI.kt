package com.kevinbaldiviesor.lunchtray.model

data class PedidoEstadoUI(
    val entrada: MenuItem.EntreeItem? = null,
    val guarnicion: MenuItem.SideDishItem? = null,
    val acompaniamiento: MenuItem.AccompanimentItem? = null,
    val itemPrecioTotal: Double = 0.0,
    val pedidoImpuesto: Double = 0.0,
    val pedidoPrecioTotal: Double = 0.0
)
