package com.kevinbaldivieso.artedigital

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kevinbaldivieso.artedigital.ui.theme.ArteDigitalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArteDigitalTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PantallaArteDigital()
                }
            }
        }
    }
}

@Composable
fun PantallaArteDigital() {
    val primeraImagen = R.drawable.angelestatua
    val segundaImagen = R.drawable.calavera
    val terceraImagen = R.drawable.cementerio
    val cuartaImagen = R.drawable.iglesia

    var carruselImagen by remember { mutableStateOf(primeraImagen) }
    var tituloImagen by remember { mutableStateOf(R.string.tituloPrimeraImagen) }
    var autorImagen by remember { mutableStateOf(R.string.autorPrimeraImagen) }
    var anioImagen by remember { mutableStateOf(R.string.anioPrimeraImagen) }

    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.70f),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ImagenMostrada(carruselImagen = carruselImagen)
        }
        DescripcionImagen(tituloImagen, autorImagen, anioImagen)
        Row(
            modifier = Modifier
                .fillMaxWidth(0.9f),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            botones(onClick = {
                when (carruselImagen) {
                    primeraImagen -> {
                        carruselImagen = segundaImagen
                        tituloImagen = R.string.tituloSegundaImagen
                        autorImagen = R.string.autorSegundaImagen
                        anioImagen = R.string.anioSegundaImagen
                    }

                    segundaImagen -> {
                        carruselImagen = terceraImagen
                        tituloImagen = R.string.tituloTerceraImagen
                        autorImagen = R.string.autorTerceraImagen
                        anioImagen = R.string.anioTerceraImagen
                    }

                    terceraImagen -> {
                        carruselImagen = cuartaImagen
                        tituloImagen = R.string.tituloCuartaImagen
                        autorImagen = R.string.autorCuartaImagen
                        anioImagen = R.string.anioCuartaImagen
                    }

                    else -> {
                        carruselImagen = primeraImagen
                        tituloImagen = R.string.tituloPrimeraImagen
                        autorImagen = R.string.autorPrimeraImagen
                        anioImagen = R.string.anioPrimeraImagen
                    }
                }
            }, texto = stringResource(id = R.string.botonPrev))
            botones(onClick = {
                when (carruselImagen) {
                    primeraImagen -> {
                        carruselImagen = cuartaImagen
                        tituloImagen = R.string.tituloCuartaImagen
                        autorImagen = R.string.autorCuartaImagen
                        anioImagen = R.string.anioCuartaImagen
                    }

                    segundaImagen -> {
                        carruselImagen = primeraImagen
                        tituloImagen = R.string.tituloPrimeraImagen
                        autorImagen = R.string.autorPrimeraImagen
                        anioImagen = R.string.anioPrimeraImagen
                    }

                    terceraImagen -> {
                        carruselImagen = segundaImagen
                        tituloImagen = R.string.tituloSegundaImagen
                        autorImagen = R.string.autorSegundaImagen
                        anioImagen = R.string.anioSegundaImagen
                    }

                    else -> {
                        carruselImagen = terceraImagen
                        tituloImagen = R.string.tituloTerceraImagen
                        autorImagen = R.string.autorTerceraImagen
                        anioImagen = R.string.anioTerceraImagen
                    }
                }
            }, texto = stringResource(id = R.string.botonSig))
        }
    }
}

@Composable
fun botones(onClick: () -> Unit, texto: String) {
    Button(
        onClick = onClick,
        modifier = Modifier.width(150.dp),
        colors = ButtonDefaults.buttonColors(Color(73, 93, 146, 255))
    ) {
        Text(
            text = texto
        )
    }
}

@Composable
fun ImagenMostrada(
    @DrawableRes carruselImagen: Int
) {
    Column(
        modifier = Modifier
            .border(border = BorderStroke(30.dp, Color.White), shape = RectangleShape)
            .shadow(30.dp)
            .fillMaxWidth()
            .fillMaxHeight(0.80f),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = carruselImagen),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
    }
}

@Composable
fun DescripcionImagen(
    @StringRes titulo: Int,
    @StringRes artista: Int,
    @StringRes anio: Int
) {
    Column(
        modifier = Modifier
            .background(Color(236, 235, 244, 255))
            .padding(horizontal = 15.dp, vertical = 15.dp)
            .fillMaxWidth(0.70f)
    ) {
        Text(
            text = stringResource(id = titulo),
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraLight
        )
        Row {
            Text(
                text = stringResource(id = artista),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = " (" + stringResource(id = anio) + ")",
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraLight
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ArteDigitalPreview() {
    ArteDigitalTheme {
        PantallaArteDigital()
    }
}