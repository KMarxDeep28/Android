package com.kevinbaldivieso.calculadoradepropinas

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performTextInput
import com.kevinbaldivieso.calculadoradepropinas.ui.theme.CalculadoraDePropinasTheme
import org.junit.Rule
import org.junit.Test
import java.text.NumberFormat

class PropinaUIPruebas {
    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun calcular_20_porciento_propina() {
        composeTestRule.setContent {
            CalculadoraDePropinasTheme {
                Surface(
                    modifier = androidx.compose.ui.Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    tiempoPropinaDisenio()
                }
            }
        }
        composeTestRule.onNodeWithText("Total de la factura")
            .performTextInput("10")
        composeTestRule.onNodeWithText("Porcentaje de propina").performTextInput("20")
        val expectedTip = NumberFormat.getCurrencyInstance().format(2)
        composeTestRule.onNodeWithText("Monto de propina: $expectedTip").assertExists(
            "No se encontró ningún nodo con este texto."
        )
    }
}

