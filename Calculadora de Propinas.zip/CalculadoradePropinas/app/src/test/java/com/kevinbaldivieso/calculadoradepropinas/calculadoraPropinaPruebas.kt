package com.kevinbaldivieso.calculadoradepropinas

import org.junit.Assert.assertEquals
import org.junit.Test
import java.text.NumberFormat

class calculadoraPropinaPruebas {
    @Test
    fun calculaPropina_20PorcientoSinRedondear() {
        val cantidad = 10.00
        val propinaPorcentaje = 20.00
        val propinaEsperada = NumberFormat.getCurrencyInstance().format(2)
        val propinaActual = calculadoraPropina(cantidad = cantidad, porcentajePropina = propinaPorcentaje, false)
        assertEquals(propinaEsperada, propinaActual)
    }
}