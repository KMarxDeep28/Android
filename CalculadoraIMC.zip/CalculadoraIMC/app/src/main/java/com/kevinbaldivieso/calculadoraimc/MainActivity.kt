package com.kevinbaldivieso.calculadoraimc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.VisibleForTesting
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kevinbaldivieso.calculadoraimc.ui.theme.CalculadoraIMCTheme
import java.text.DecimalFormat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CalculadoraIMCTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DisenioIMC()
                }
            }
        }
    }
}

@Composable
fun DisenioIMC() {
    var pesoEntrada by remember { mutableStateOf("") }
    var alturaEntrada by remember { mutableStateOf("") }
    var medida by remember { mutableStateOf(false) }

    val peso = pesoEntrada.toDoubleOrNull() ?: 0.0
    val altura = alturaEntrada.toDoubleOrNull() ?: 0.0
    val valorIMC = calcularIMC(peso, altura, medida)

    val medidaUsadaPeso =
        if (medida) stringResource(id = R.string.unidadPesoIngles) else stringResource(id = R.string.unidadPeso)
    val medidaUsadaAltura =
        if (medida) stringResource(id = R.string.unidadAlturaIngles) else stringResource(id = R.string.unidadAltura)

    Column(
        modifier = Modifier
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(0.9f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            InsercionDatos(
                icono = R.drawable.peso,
                textoFondo = stringResource(id = R.string.peticionPeso) + " $medidaUsadaPeso",
                valor = pesoEntrada,
                cambioValor = { pesoEntrada = it },
                tecladoOpciones = KeyboardOptions.Default.copy(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Next
                )
            )
            Spacer(modifier = Modifier.height(30.dp))
            InsercionDatos(
                icono = R.drawable.altura,
                textoFondo = stringResource(id = R.string.peticionAltura) + " $medidaUsadaAltura",
                valor = alturaEntrada,
                cambioValor = { alturaEntrada = it },
                tecladoOpciones = KeyboardOptions.Default.copy(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                )
            )
        }
        Spacer(modifier = Modifier.height(30.dp))
        UnidadMedida(
            verificacion = medida,
            verificacionCambio = { medida = it })
        Spacer(modifier = Modifier.height(30.dp))
        Text(
            text = stringResource(
                id = R.string.valorIMC,
                valorIMC
            ) + "\n" + stringResource(estadoIMC(valorIMC.toDouble())),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(
            modifier = Modifier
                .height(30.dp)
                .padding(horizontal = 12.dp, vertical = 12.dp)
        )
        Card(
            modifier = Modifier
                .shadow(12.dp)
                .fillMaxWidth(0.8f),
            border = BorderStroke(width = 1.dp, color = Color.Gray)
        ) {
            Text(
                text = stringResource(id = R.string.bajoPeso) + "\n"
                        + stringResource(id = R.string.normalPeso) + "\n"
                        + stringResource(id = R.string.sobrePeso) + "\n"
                        + stringResource(id = R.string.obesidad),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun InsercionDatos(
    icono: Int,
    textoFondo: String,
    valor: String,
    cambioValor: (String) -> Unit,
    tecladoOpciones: KeyboardOptions
) {
    TextField(
        value = valor,
        onValueChange = cambioValor,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(text = textoFondo) },
        leadingIcon = {
            Icon(
                painter = painterResource(id = icono),
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
        },
        keyboardOptions = tecladoOpciones,
        singleLine = true
    )
}

@VisibleForTesting
fun calcularIMC(peso: Double, altura: Double, medida: Boolean): String {
    var valorIMC = peso / (altura * altura)
    if (medida) {
        valorIMC *= 703
    }
    if (altura <= 0.0 || peso <= 0) {
        valorIMC = 0.0
    }
    return DecimalFormat(".0").format(valorIMC)
}

@Composable
fun UnidadMedida(verificacion: Boolean, verificacionCambio: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(0.8f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = stringResource(R.string.unidadMedida))
        Switch(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentWidth(Alignment.End),
            checked = verificacion,
            onCheckedChange = verificacionCambio
        )
    }
}


fun estadoIMC(valorIMC: Double): Int {
    val estado = when {
        valorIMC < 18.5 -> R.string.pesoBajo
        valorIMC < 24.9 -> R.string.pesoNormal
        valorIMC < 29.9 -> R.string.pesoSobrepeso
        else -> R.string.pesoObesidad
    }
    return estado
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    CalculadoraIMCTheme {
        DisenioIMC()
    }
}