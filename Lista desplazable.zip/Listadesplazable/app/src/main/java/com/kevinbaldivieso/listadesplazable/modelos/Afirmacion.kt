package com.kevinbaldivieso.listadesplazable.modelos

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Afirmacion(
    @StringRes val textoId: Int,
    @DrawableRes val imagenId: Int
)
