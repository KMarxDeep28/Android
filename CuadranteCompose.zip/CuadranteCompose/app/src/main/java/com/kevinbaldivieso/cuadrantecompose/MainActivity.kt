package com.kevinbaldivieso.cuadrantecompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.kevinbaldivieso.cuadrantecompose.ui.theme.CuadranteComposeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CuadranteComposeTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CuadranteCompose(
                        stringResource(R.string.titulo1),
                        stringResource(R.string.parrafo1),
                        stringResource(R.string.titulo2),
                        stringResource(R.string.parrafo2),
                        stringResource(R.string.titulo3),
                        stringResource(R.string.parrafo3),
                        stringResource(R.string.titulo4),
                        stringResource(R.string.parrafo4))
                }
            }
        }
    }
}

@Composable
fun CuadranteCompose(t1: String,p1: String,t2: String,p2: String,t3: String,p3: String,t4: String,p4: String) {
    Column(Modifier
        .fillMaxWidth()) {
        Row(Modifier
            .weight(1f)) {
            TarjetaCompose(t1, p1, Color(0xFFEADDFF), Modifier.weight(1f))
            TarjetaCompose(t2, p2, Color(0xFFD0BCFF), Modifier.weight(1f))
        }
        Row(Modifier
            .weight(1f)) {
            TarjetaCompose(t3, p3, Color(0xFFB69DF8), Modifier.weight(1f))
            TarjetaCompose(t4, p4, Color(0xFFF6EDFF), Modifier.weight(1f))
        }
    }
}

@Composable
fun TarjetaCompose(titulo: String, parrafo: String, colorFondo: Color, modifier: Modifier) {
    Column(
        modifier
            .fillMaxSize()
            .background(colorFondo)
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = titulo,
            modifier = Modifier
                .padding(bottom = 16.dp),
            fontWeight = FontWeight.Bold
        )
        Text(
            text = parrafo,
            textAlign = TextAlign.Justify
        )
    }
}

@Preview(showBackground = true)
@Composable
fun TarjetaComposePrev() {
    CuadranteComposeTheme {
        CuadranteCompose(
            stringResource(R.string.titulo1),
            stringResource(R.string.parrafo1),
            stringResource(R.string.titulo2),
            stringResource(R.string.parrafo2),
            stringResource(R.string.titulo3),
            stringResource(R.string.parrafo3),
            stringResource(R.string.titulo4),
            stringResource(R.string.parrafo4))
    }
}