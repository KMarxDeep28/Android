package com.kevinbaldivieso.unscramble.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.material3.MaterialTheme.shapes
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kevinbaldivieso.unscramble.R
import com.kevinbaldivieso.unscramble.ui.theme.UnscrambleTheme

@Composable
fun PantallaJuego(modeloVistaJuego: ModeloVistaJuego = viewModel()) {
    val juegoUIEstado by modeloVistaJuego.estadoUI.collectAsState()
    val paddingMedio = dimensionResource(R.dimen.padding_medium)

    Column(
        modifier = Modifier
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(paddingMedio),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = stringResource(R.string.app_name),
            style = typography.titleLarge,
        )
        DisenioJuego(
            unUsuarioAdivinaCambio = { modeloVistaJuego.actualizarAdivinaUsuario(it) },
            palabraContador = juegoUIEstado.palabraActualContador,
            usuarioAdivina = modeloVistaJuego.usuarioAdivina,
            unTecladoListo = { modeloVistaJuego.comprobarUssuarioAdivina() },
            palabraScrambledActual = juegoUIEstado.palabraScrambledActual,
            errorAdivina = juegoUIEstado.esPalabraAdivinadaErronea,
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(paddingMedio)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(paddingMedio),
            verticalArrangement = Arrangement.spacedBy(paddingMedio),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    modeloVistaJuego.comprobarUssuarioAdivina()
                }
            ) {
                Text(
                    text = stringResource(R.string.submit),
                    fontSize = 16.sp
                )
            }

            OutlinedButton(
                onClick = {modeloVistaJuego.saltarPalabra() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stringResource(R.string.skip),
                    fontSize = 16.sp
                )
            }
        }

        EstadoJuego(puntaje = juegoUIEstado.palabraActualContador, modifier = Modifier.padding(20.dp))
        if (juegoUIEstado.juegoTerminado){
            PuntajeFinalDialogo(
                puntaje = juegoUIEstado.puntaje,
                volverAJugar = { modeloVistaJuego.resetearJuego() }
            )
        }
    }
}

@Composable
fun EstadoJuego(puntaje: Int, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
    ) {
        Text(
            text = stringResource(R.string.score, puntaje),
            style = typography.headlineMedium,
            modifier = Modifier.padding(8.dp)
        )
    }
}

@Composable
fun DisenioJuego(
    palabraScrambledActual: String,
    palabraContador: Int,
    errorAdivina: Boolean,
    usuarioAdivina: String,
    unUsuarioAdivinaCambio: (String) -> Unit,
    unTecladoListo: () -> Unit,

    modifier: Modifier = Modifier,
) {
    val paddingMedio = dimensionResource(R.dimen.padding_medium)

    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(paddingMedio),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(paddingMedio)
        ) {
            Text(
                modifier = Modifier
                    .clip(shapes.medium)
                    .background(colorScheme.surfaceTint)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .align(alignment = Alignment.End),
                text = stringResource(R.string.word_count, palabraContador),
                style = typography.titleMedium,
                color = colorScheme.onPrimary
            )
            Text(
                text = palabraScrambledActual,
                style = typography.displayMedium
            )
            Text(
                text = stringResource(R.string.instructions),
                textAlign = TextAlign.Center,
                style = typography.titleMedium
            )
            OutlinedTextField(
                value = usuarioAdivina,
                singleLine = true,
                shape = shapes.large,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = colorScheme.surface,
                    unfocusedContainerColor = colorScheme.surface,
                    disabledContainerColor = colorScheme.surface,
                ),
                onValueChange = unUsuarioAdivinaCambio,
                label = {
                    if (errorAdivina) {
                        Text(stringResource(R.string.wrong_guess))
                    } else {
                        Text(stringResource(R.string.enter_your_word))
                    }
                },
                isError = errorAdivina,
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { unTecladoListo() }
                )
            )
        }
    }
}



@Composable
private fun PuntajeFinalDialogo(
    puntaje: Int,
    volverAJugar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activity = (LocalContext.current as Activity)

    AlertDialog(
        onDismissRequest = {
            // Dismiss the dialog when the user clicks outside the dialog or on the back
            // button. If you want to disable that functionality, simply use an empty
            // onCloseRequest.
        },
        title = { Text(text = stringResource(R.string.congratulations)) },
        text = { Text(text = stringResource(R.string.you_scored, puntaje)) },
        modifier = modifier,
        dismissButton = {
            TextButton(
                onClick = {
                    activity.finish()
                }
            ) {
                Text(text = stringResource(R.string.exit))
            }
        },
        confirmButton = {
            TextButton(onClick = volverAJugar) {
                Text(text = stringResource(R.string.play_again))
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
fun GameScreenPreview() {
    UnscrambleTheme {
        PantallaJuego()
    }
}
