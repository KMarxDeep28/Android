package com.kevinbaldivieso.unscramble.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.kevinbaldivieso.unscramble.datos.MAX_NO_OF_WORDS
import com.kevinbaldivieso.unscramble.datos.SCORE_INCREASE
import com.kevinbaldivieso.unscramble.datos.DatosPalabras
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class ModeloVistaJuego : ViewModel() {

    private val _estadoUI = MutableStateFlow(EstadoUIJuego())
    val estadoUI: StateFlow<EstadoUIJuego> = _estadoUI.asStateFlow()

    var usuarioAdivina by mutableStateOf("")
        private set

    private var palabrasUsadas: MutableSet<String> = mutableSetOf()
    private lateinit var palabraActual: String

    init {
        resetearJuego()
    }

    fun resetearJuego() {
        palabrasUsadas.clear()
        _estadoUI.value = EstadoUIJuego(palabraScrambledActual = elegirPalabraAleatoriaMezclada())

    }

    fun actualizarAdivinaUsuario(palabraAdivinada: String){
        usuarioAdivina = palabraAdivinada
    }

    //comprobar aqui
    fun comprobarUssuarioAdivina() {
        if (usuarioAdivina.equals(palabraActual, ignoreCase = true)) {
            val puntajeActualizado = _estadoUI.value.puntaje.plus(SCORE_INCREASE)
            actualizarEstadoJuego(puntajeActualizado)
        } else {
            _estadoUI.update { currentState ->
                currentState.copy(esPalabraAdivinadaErronea = true)
            }
        }
        actualizarAdivinaUsuario("")
    }

    fun saltarPalabra(){
        actualizarEstadoJuego(_estadoUI.value.puntaje)
        actualizarAdivinaUsuario("")
    }

    private fun actualizarEstadoJuego(actualizarPuntaje: Int) {
        if (palabrasUsadas.size == MAX_NO_OF_WORDS) {
            _estadoUI.update { estadoActual ->
                estadoActual.copy(
                    esPalabraAdivinadaErronea = false,
                    puntaje = actualizarPuntaje,
                    juegoTerminado = true
                )
            }
        } else {
            _estadoUI.update { estadoActual ->
                estadoActual.copy(
                    esPalabraAdivinadaErronea = false,
                    palabraScrambledActual = elegirPalabraAleatoriaMezclada(),
                    palabraActualContador = estadoActual.palabraActualContador.inc(),
                    puntaje = actualizarPuntaje
                )
            }
        }
    }

    private fun mezclarPalabraActual(palabra: String): String {
        val tempPalabra = palabra.toCharArray()
        tempPalabra.shuffle()
        while (String(tempPalabra) == palabra) {
            tempPalabra.shuffle()
        }
        return String(tempPalabra)
    }

    private fun elegirPalabraAleatoriaMezclada(): String {
        palabraActual = DatosPalabras.random()
        return if (palabrasUsadas.contains(palabraActual)) {
             elegirPalabraAleatoriaMezclada()
        } else {
            palabrasUsadas.add(palabraActual)
            mezclarPalabraActual(palabraActual)
        }
    }

}