package com.kevinbaldivieso.unscramble.ui

data class EstadoUIJuego(
    val palabraScrambledActual: String = "",
    val palabraActualContador: Int = 1,
    val puntaje: Int = 0,
    val esPalabraAdivinadaErronea: Boolean = false,
    val juegoTerminado: Boolean = false
)
