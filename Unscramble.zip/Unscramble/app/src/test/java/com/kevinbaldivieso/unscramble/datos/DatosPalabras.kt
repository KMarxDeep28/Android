package com.kevinbaldivieso.unscramble.datos

const val MAX_NO_OF_WORDS = 10
const val SCORE_INCREASE = 20

val DatosPalabras: Set<String> =
    setOf(
        "at",
        "sea",
        "home",
        "classic",
        "arise",
        "banana",
        "android",
        "birthday",
        "briefcase",
        "motorcycle",
        "cauliflower"
    )

private val tamanioPalabraMap: Map<Int, String> = DatosPalabras.associateBy({ it.length }, { it })

internal fun obtenerPalabraUnscrambled(palabraScramble: String) = tamanioPalabraMap[palabraScramble.length] ?: ""
