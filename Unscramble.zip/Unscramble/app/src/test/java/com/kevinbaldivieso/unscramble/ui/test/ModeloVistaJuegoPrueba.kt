package com.kevinbaldivieso.unscramble.ui.test

import com.kevinbaldivieso.unscramble.datos.MAX_NO_OF_WORDS
import com.kevinbaldivieso.unscramble.datos.SCORE_INCREASE
import com.kevinbaldivieso.unscramble.datos.obtenerPalabraUnscrambled
import com.kevinbaldivieso.unscramble.ui.ModeloVistaJuego
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModeloVistaJuegoPrueba {
    private val modeloVista = ModeloVistaJuego()

        @Test
        fun modeloVistaJuego_InicializaPrimeraPalabraCargada() {

            val juegoUIEstado = modeloVista.estadoUI.value
            val palabraScrambled = obtenerPalabraUnscrambled(juegoUIEstado.palabraScrambledActual)

            assertNotEquals(palabraScrambled, juegoUIEstado.palabraScrambledActual)
            assertTrue(juegoUIEstado.palabraActualContador == 1)
            assertTrue(juegoUIEstado.puntaje == 0)
            assertFalse(juegoUIEstado.esPalabraAdivinadaErronea)
            assertFalse(juegoUIEstado.juegoTerminado)
        }

        @Test
        fun modeloVistaJuego_AdivinaIncorrectamente_BanderaErrorSet() {
            val palabraIncorrectaJugador = "and"

            modeloVista.actualizarAdivinaUsuario(palabraIncorrectaJugador)
            modeloVista.comprobarUssuarioAdivina()

            val currentGameUiState = modeloVista.estadoUI.value
            assertEquals(0, currentGameUiState.puntaje)
            assertTrue(currentGameUiState.esPalabraAdivinadaErronea)
        }

    @Test
    fun modeloVistaJuego_PalabraCorrectaAdivinada_ActualizarPuntajeYErrorFlagUnset() {
        var estadoJuegoUIActual = modeloVista.estadoUI.value
        val palabraCorrectaJugador = obtenerPalabraUnscrambled(estadoJuegoUIActual.palabraScrambledActual)

        modeloVista.actualizarAdivinaUsuario(palabraCorrectaJugador)
        modeloVista.comprobarUssuarioAdivina()
        estadoJuegoUIActual = modeloVista.estadoUI.value

        assertFalse(estadoJuegoUIActual.esPalabraAdivinadaErronea)
        assertEquals(SCORE_AFTER_FIRST_CORRECT_ANSWER, estadoJuegoUIActual.puntaje)
    }

    @Test
    fun modeloVistaJuego_PalabraSaltada_PuntajeSinCambioEIncrementoPalabraContador() {
        var estadoJuegoUIActual = modeloVista.estadoUI.value
        val palabraCorrectaJugador = obtenerPalabraUnscrambled(estadoJuegoUIActual.palabraScrambledActual)

        modeloVista.actualizarAdivinaUsuario(palabraCorrectaJugador)
        modeloVista.comprobarUssuarioAdivina()
        estadoJuegoUIActual = modeloVista.estadoUI.value
        val lastWordCount = estadoJuegoUIActual.palabraActualContador

        modeloVista.saltarPalabra()
        estadoJuegoUIActual = modeloVista.estadoUI.value
        assertEquals(SCORE_AFTER_FIRST_CORRECT_ANSWER, estadoJuegoUIActual.puntaje)
        assertEquals(lastWordCount + 1, estadoJuegoUIActual.palabraActualContador)
    }

    @Test
    fun modeloVistaJuego_TodasPalabrasAdivinadas_EstaodUIActualizadoCorrectamente() {
        var puntajeEsperado = 0
        var estadoJuegoUIActual = modeloVista.estadoUI.value
        var palabraCorrectaJugador = obtenerPalabraUnscrambled(estadoJuegoUIActual.palabraScrambledActual)

        repeat(MAX_NO_OF_WORDS) {
            puntajeEsperado += SCORE_INCREASE
            modeloVista.actualizarAdivinaUsuario(palabraCorrectaJugador)
            modeloVista.comprobarUssuarioAdivina()
            estadoJuegoUIActual = modeloVista.estadoUI.value
            palabraCorrectaJugador = obtenerPalabraUnscrambled(estadoJuegoUIActual.palabraScrambledActual)
            assertEquals(puntajeEsperado, estadoJuegoUIActual.puntaje)
        }
        assertEquals(MAX_NO_OF_WORDS, estadoJuegoUIActual.palabraActualContador)
        assertTrue(estadoJuegoUIActual.juegoTerminado)
    }

    companion object {
        private const val SCORE_AFTER_FIRST_CORRECT_ANSWER = SCORE_INCREASE
    }
}