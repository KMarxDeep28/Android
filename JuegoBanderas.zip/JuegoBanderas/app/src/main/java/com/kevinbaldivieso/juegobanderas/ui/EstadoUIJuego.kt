package com.kevinbaldivieso.juegobanderas.ui

import androidx.annotation.DrawableRes
import com.kevinbaldivieso.juegobanderas.datos.RecursoDatos.banderaLista

const val MAXIMO_PREGUNTAS = 10


data class EstadoUIJuego(
    val indiceBanderaActual: Int = 0,
    @DrawableRes val imagenbanderaActual: Int = banderaLista[indiceBanderaActual].imagendId,
    val nombreBanderaActual: String = banderaLista[indiceBanderaActual].nombre,
    val actualContador: Int = 1,
    val aciertos: Int = 0,
    val fallos: Int = 0,
    val esBanderaErronea: Boolean = false,
    val juegoTerminado: Boolean = false
)
