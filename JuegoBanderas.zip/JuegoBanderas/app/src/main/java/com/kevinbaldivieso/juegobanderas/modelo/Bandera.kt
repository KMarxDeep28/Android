
package com.kevinbaldivieso.juegobanderas.modelo

data class Bandera(val imagendId: Int, val nombre: String)
