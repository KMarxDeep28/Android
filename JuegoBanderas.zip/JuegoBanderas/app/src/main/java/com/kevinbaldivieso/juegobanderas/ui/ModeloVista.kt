package com.kevinbaldivieso.juegobanderas.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.kevinbaldivieso.juegobanderas.datos.RecursoDatos.banderaLista
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

class ModeloVista : ViewModel() {
    private val _estadoUI = MutableStateFlow(EstadoUIJuego())
    val estadoUI: StateFlow<EstadoUIJuego> = _estadoUI.asStateFlow()

    var usuarioAdivina by mutableStateOf("")
        private set

    private var banderasUsadas: MutableSet<Int> = mutableSetOf()
    private var banderaActualImagen: Int = 0
    private var nombreBandera: String = ""//Int = 0

    init {
        resetearJuego()
    }

    fun resetearJuego() {
        banderasUsadas.clear()
        _estadoUI.value = EstadoUIJuego(
            imagenbanderaActual = elegirBanderaAleatoriaMezclada(),
            nombreBanderaActual = nombreBandera//RecursoDatos.banderaNombreString(nombreBandera)
        )
    }

    private fun elegirBanderaAleatoriaMezclada(): Int {
        val indice = determinarIndiceAleatorio()
        banderaActualImagen = banderaLista[indice].imagendId
        nombreBandera = banderaLista[indice].nombre
        return if (banderasUsadas.contains(banderaActualImagen)) {
            elegirBanderaAleatoriaMezclada()
        } else {
            banderasUsadas.add(banderaActualImagen)
            mezclarBanderaActual(indice)
        }
    }

    private fun mezclarBanderaActual(indice: Int): Int {
        return banderaLista[indice].imagendId
    }

    private fun determinarIndiceAleatorio(): Int {
        return Random.nextInt(banderaLista.size)
    }

    private fun actualizarEstadoJuego(
        actualizarPuntajeAciertos: Int,
        actualizarPuntajeFallos: Int,
        auxCondicional: Boolean = true
    ) {
        if (banderasUsadas.size == MAXIMO_PREGUNTAS) {
            _estadoUI.update { estadoActual ->
                estadoActual.copy(
                    esBanderaErronea = false,
                    aciertos = actualizarPuntajeAciertos,
                    fallos = actualizarPuntajeFallos,
                    juegoTerminado = true
                )
            }
        } else {
            if (auxCondicional) {
                _estadoUI.update { estadoActual ->
                    estadoActual.copy(
                        esBanderaErronea = false,
                        imagenbanderaActual = elegirBanderaAleatoriaMezclada(),
                        nombreBanderaActual = nombreBandera,//RecursoDatos.banderaNombreString(nombreBandera),
                        actualContador = estadoActual.actualContador.inc(),
                        aciertos = actualizarPuntajeAciertos,
                        fallos = actualizarPuntajeFallos,
                    )
                }
            } else {
                _estadoUI.update { estadoActual ->
                    estadoActual.copy(
                        esBanderaErronea = true,
                        nombreBanderaActual = nombreBandera,//RecursoDatos.banderaNombreString(nombreBandera),
                        aciertos = actualizarPuntajeAciertos,
                        fallos = actualizarPuntajeFallos,
                    )
                }
            }
        }
    }

    fun comprobarUsuarioAdivina() {
        val usuarioAdivinaAux = usuarioAdivina.trim().toLowerCase()
        if (usuarioAdivinaAux.isNotBlank()) {
            if (usuarioAdivinaAux.equals(
                    nombreBandera/*RecursoDatos.banderaNombreString(nombreBandera)*/,
                    true
                )
            ) {
                val puntajeActualizadoAciertos = _estadoUI.value.aciertos.plus(+1)
                val puntajeActualizadoFallos = _estadoUI.value.fallos.plus(+0)
                actualizarEstadoJuego(puntajeActualizadoAciertos, puntajeActualizadoFallos, true)
            } else {
                val puntajeActualizadoAciertos = _estadoUI.value.aciertos.plus(+0)
                val puntajeActualizadoFallos = _estadoUI.value.fallos.plus(+1)
                actualizarEstadoJuego(puntajeActualizadoAciertos, puntajeActualizadoFallos, false)
                _estadoUI.update { estadoActual ->
                    estadoActual.copy(esBanderaErronea = true)
                }
            }
            actualizarAdivinaUsuario("")
        } else {
            _estadoUI.update { estadoActual ->
                estadoActual.copy(esBanderaErronea = true)
            }
        }
    }

    fun actualizarAdivinaUsuario(banderaAdivinada: String) {

        usuarioAdivina = banderaAdivinada
    }

    fun saltarBandera() {
        actualizarEstadoJuego(_estadoUI.value.aciertos, _estadoUI.value.fallos.plus(+1))
        actualizarAdivinaUsuario("")
    }

    fun porcentajeBandera(aciertos: Int, errores: Int): Int {
        val total = aciertos + errores
        return ((100 * aciertos) / total)
    }

}