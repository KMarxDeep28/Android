package com.kevinbaldivieso.juegobanderas

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandIn
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kevinbaldivieso.juegobanderas.ui.ModeloVista
import com.kevinbaldivieso.juegobanderas.ui.theme.JuegoBanderasTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JuegoBanderasTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PantallaJuego()
                }
            }
        }
    }
}


@Composable
fun PantallaJuego(modeloVista: ModeloVista = viewModel()) {

    val juegoUIEstado by modeloVista.estadoUI.collectAsState()

    Column(
        modifier = Modifier
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .safeDrawingPadding()
            .padding(8.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.titleLarge,
        )
        DisenioJuego(
            usuarioAdivina = modeloVista.usuarioAdivina,
            unUsuarioAdivinaCambio = { modeloVista.actualizarAdivinaUsuario(it) },
            unTecladoListo = { modeloVista.comprobarUsuarioAdivina() },
            banderaContador = juegoUIEstado.actualContador,
            errorAdivina = juegoUIEstado.esBanderaErronea,
            imagenBanderaActual = juegoUIEstado.imagenbanderaActual,

            //nombre = juegoUIEstado.nombreBanderaActual,

            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(8.dp)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    modeloVista.comprobarUsuarioAdivina()
                }
            ) {
                Text(
                    text = stringResource(R.string.enviar),
                    fontSize = 16.sp
                )
            }
            OutlinedButton(
                onClick = { modeloVista.saltarBandera() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stringResource(R.string.saltar),
                    fontSize = 16.sp
                )
            }
        }

        Row {
            EstadoJuego(
                textoMostrado = R.string.aciertos,
                contadorAdecuado = juegoUIEstado.aciertos,
                modifier = Modifier.padding(20.dp),
                color = Color.Green
            )
            EstadoJuego(
                textoMostrado = R.string.errores,
                contadorAdecuado = juegoUIEstado.fallos,
                modifier = Modifier.padding(20.dp),
                color = Color.Red
            )
        }


        if (juegoUIEstado.juegoTerminado) {
            PuntajeFinalDialogo(
                puntajeAciertos = juegoUIEstado.aciertos,
                puntajeFallos = juegoUIEstado.fallos,
                porcentaje = modeloVista.porcentajeBandera(
                    juegoUIEstado.aciertos,
                    juegoUIEstado.fallos
                ),
                volverAJugar = { modeloVista.resetearJuego() }
            )
        }
    }
}

@Composable
fun EstadoJuego(
    textoMostrado: Int,
    contadorAdecuado: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
    ) {
        Text(
            text = stringResource(textoMostrado, contadorAdecuado),
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(8.dp),
            color = color
        )
    }
}

@Composable
fun DisenioJuego(
    imagenBanderaActual: Int,
    unTecladoListo: () -> Unit,
    banderaContador: Int,
    errorAdivina: Boolean,
    usuarioAdivina: String,
    unUsuarioAdivinaCambio: (String) -> Unit,
    modifier: Modifier = Modifier,

    //nombre: String
) {

    var esVisible by remember { mutableStateOf(false) }

    // Trigger animation when the image changes
    LaunchedEffect(imagenBanderaActual) {
        esVisible = false
        delay(200) // Delay before showing the new image
        esVisible = true
    }

    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(8.dp)
        ) {
            Text(
                modifier = Modifier
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceTint)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .align(alignment = Alignment.End),
                text = stringResource(id = R.string.bandera_contador, banderaContador),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary
            )
            AnimatedVisibility(
                visible = esVisible,
                enter = fadeIn(animationSpec = tween(durationMillis = 1000)) + expandIn(),
                exit = fadeOut(animationSpec = tween(durationMillis = 500)) + shrinkOut()
            ) {
                Image(
                    painter = painterResource(id = imagenBanderaActual),
                    contentDescription = null,
                    modifier = Modifier.size(width = 300.dp, height = 150.dp),
                )
            }
            Text(
                text = stringResource(R.string.instruccion),// + stringResource(id = R.string.respuesta, nombre),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium
            )

            OutlinedTextField(
                value = usuarioAdivina,
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    disabledContainerColor = MaterialTheme.colorScheme.surface,
                ),
                onValueChange = unUsuarioAdivinaCambio,
                label = {
                    if (errorAdivina) {
                        Text(stringResource(R.string.intentoError))
                    } else {
                        Text(stringResource(R.string.Ingrese))
                    }
                },
                isError = errorAdivina,
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { unTecladoListo() }
                )
            )
        }
    }
}

@Composable
fun PuntajeFinalDialogo(
    puntajeAciertos: Int,
    puntajeFallos: Int,
    porcentaje: Int,
    volverAJugar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activity = (LocalContext.current as Activity)

    AlertDialog(
        onDismissRequest = {},
        title = { Text(text = stringResource(R.string.felicidades)) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.8f),
            ) {
                Text(
                    text = stringResource(id = R.string.porcentaje, porcentaje) + "%",
                    fontSize = 20.sp
                )
                Spacer(modifier = Modifier.padding(vertical = 8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Text(text = stringResource(R.string.aciertos, puntajeAciertos))
                    Text(text = stringResource(id = R.string.errores, puntajeFallos))
                }
            }
        },
        modifier = modifier,
        dismissButton = {
            TextButton(
                onClick = {
                    activity.finish()
                }
            ) {
                Text(text = stringResource(R.string.salir))
            }
        },
        confirmButton = {
            TextButton(onClick = volverAJugar) {
                Text(text = stringResource(R.string.jugarNuevamente))
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
private fun PantallaJuegoPreview() {
    JuegoBanderasTheme {
        PantallaJuego()
    }

    /*PuntajeFinalDialogo(
        puntajeAciertos = juegoUIEstado.aciertos,
        puntajeFallos = juegoUIEstado.fallos,
        porcentaje = modeloVista.porcentajeBandera(),
        volverAJugar = { modeloVista.resetearJuego() },
        modifier = Modifier.fillMaxSize()
    )*/
}