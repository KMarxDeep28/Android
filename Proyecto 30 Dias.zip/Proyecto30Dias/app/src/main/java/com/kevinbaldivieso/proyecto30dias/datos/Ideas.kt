package com.kevinbaldivieso.proyecto30dias.datos

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.kevinbaldivieso.proyecto30dias.R

data class estructuraObjetivos(
    @StringRes val dia: Int,
    @StringRes val objetivo: Int,
    @DrawableRes val imagen: Int,
    @StringRes val descripcion: Int
)

val objetivos = listOf(
    estructuraObjetivos(R.string.dia1, R.string.objetivo1, R.drawable.objetivo1, R.string.descripcion1),
    estructuraObjetivos(R.string.dia2, R.string.objetivo2, R.drawable.objetivo2, R.string.descripcion2),
    estructuraObjetivos(R.string.dia3, R.string.objetivo3, R.drawable.objetivo3, R.string.descripcion3),
    estructuraObjetivos(R.string.dia4, R.string.objetivo4, R.drawable.objetivo4, R.string.descripcion4),
    estructuraObjetivos(R.string.dia5, R.string.objetivo5, R.drawable.objetivo5, R.string.descripcion5),
    estructuraObjetivos(R.string.dia6, R.string.objetivo6, R.drawable.objetivo6, R.string.descripcion6),
    estructuraObjetivos(R.string.dia7, R.string.objetivo7, R.drawable.objetivo7, R.string.descripcion7),
    estructuraObjetivos(R.string.dia8, R.string.objetivo8, R.drawable.objetivo8, R.string.descripcion8),
    estructuraObjetivos(R.string.dia9, R.string.objetivo9, R.drawable.objetivo9, R.string.descripcion9),
    estructuraObjetivos(R.string.dia10, R.string.objetivo10, R.drawable.objetivo10, R.string.descripcion10),
    estructuraObjetivos(R.string.dia11, R.string.objetivo11, R.drawable.objetivo11, R.string.descripcion11),
    estructuraObjetivos(R.string.dia12, R.string.objetivo12, R.drawable.objetivo12, R.string.descripcion12),
    estructuraObjetivos(R.string.dia13, R.string.objetivo13, R.drawable.objetivo13, R.string.descripcion13),
    estructuraObjetivos(R.string.dia14, R.string.objetivo14, R.drawable.objetivo14, R.string.descripcion14),
    estructuraObjetivos(R.string.dia15, R.string.objetivo15, R.drawable.objetivo15, R.string.descripcion15),
    estructuraObjetivos(R.string.dia16, R.string.objetivo16, R.drawable.objetivo16, R.string.descripcion16),
    estructuraObjetivos(R.string.dia17, R.string.objetivo17, R.drawable.objetivo17, R.string.descripcion17),
    estructuraObjetivos(R.string.dia18, R.string.objetivo18, R.drawable.objetivo18, R.string.descripcion18),
    estructuraObjetivos(R.string.dia19, R.string.objetivo19, R.drawable.objetivo19, R.string.descripcion19),
    estructuraObjetivos(R.string.dia20, R.string.objetivo20, R.drawable.objetivo20, R.string.descripcion20),
    estructuraObjetivos(R.string.dia21, R.string.objetivo21, R.drawable.objetivo21, R.string.descripcion21),
    estructuraObjetivos(R.string.dia22, R.string.objetivo22, R.drawable.objetivo22, R.string.descripcion22),
    estructuraObjetivos(R.string.dia23, R.string.objetivo23, R.drawable.objetivo23, R.string.descripcion23),
    estructuraObjetivos(R.string.dia24, R.string.objetivo24, R.drawable.objetivo24, R.string.descripcion24),
    estructuraObjetivos(R.string.dia25, R.string.objetivo25, R.drawable.objetivo25, R.string.descripcion25),
    estructuraObjetivos(R.string.dia26, R.string.objetivo26, R.drawable.objetivo26, R.string.descripcion26),
    estructuraObjetivos(R.string.dia27, R.string.objetivo27, R.drawable.objetivo27, R.string.descripcion27),
    estructuraObjetivos(R.string.dia28, R.string.objetivo28, R.drawable.objetivo28, R.string.descripcion28),
    estructuraObjetivos(R.string.dia29, R.string.objetivo29, R.drawable.objetivo29, R.string.descripcion29),
    estructuraObjetivos(R.string.dia30, R.string.objetivo30, R.drawable.objetivo30, R.string.descripcion30),

)